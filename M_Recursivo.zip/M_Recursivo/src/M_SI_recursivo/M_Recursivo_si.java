/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package M_SI_recursivo;
    import java.util.*;
/**
 *
 * @author salas
 */
public class M_Recursivo_si {

    public static int Factorial(int N){
        if(N == 1)
            return 1;
        else
            return N*Factorial(N-1);
    }
    
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
            int numero;
                System.out.println("Ingrese el número al que desea calcular su factorial");
                    numero = sc.nextInt();
                        System.out.println("El factorial de "+ numero+" es: "+ Factorial(numero));
    }
}
