/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package M_SI_recursivo;

import java.util.Scanner;

/**
 *
 * @author salas
 */
public class Fibo_si {

    public static int FN(int ciclos){
    int a=0;
    int b=1;
        if(ciclos==1)
            return 0;
        else
            return FN(ciclos-1)+(ciclos-2);
    }
     
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
            int c;
                System.out.println("ingrese el numero que desea: ");
                    c= sc.nextInt();
                        System.out.println("la sucecion terminaria en: "+FN(c));
                    
}
}
