/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package M_SI_recursivo;

import java.util.Scanner;

/**
 *
 * @author salas
 */
public class Potencia_si {

    public static int potencia(int base, int exponente){
        if(exponente==0)
            return 1;
        else
            return base*potencia(base, exponente-1);
    }
    
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
            int b,e;
                System.out.println("ingrese la base: ");
                    b = sc.nextInt();
                System.out.println("ingrese el exponente: ");
                    e = sc.nextInt();
                        System.out.println("el resultado de la potencia es: "+potencia(b,e));
    }
}
