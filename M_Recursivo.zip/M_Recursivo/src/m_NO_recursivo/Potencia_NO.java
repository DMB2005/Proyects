/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m_NO_recursivo;
    import java.util.*;
/**
 *
 * @author salas
 */
public class Potencia_NO {
 
    public static int potencia(int base, int exponente){
        int pot = 1;
            for (int i = 1; i<= exponente; i++)
                pot = pot*base;
        return pot;
    }
    
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
            int b,e;
                System.out.println("ingrese la base: ");
                    b = sc.nextInt();
                System.out.println("ingrese el exponente: ");
                    e = sc.nextInt();
                        System.out.println("el resultado de la potencia es: "+potencia(b,e));
    }
}
