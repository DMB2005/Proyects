/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m_NO_recursivo;
    import java.util.*;
/**
 *
 * @author salas
 */
public class M_NO_Recursivo {

    /**
     * @param args the command line arguments
     */
    public static int Factorial(int N) {
        int fact=1;
            for(int i = 0;i>=1;i--)
                fact = fact*i;
    return fact;
    }
    
    public static void main (String args[]){
        Scanner sc = new Scanner(System.in);
            int numero;
                System.out.println("Ingrese el número al que desea calcular su factorial");
                    numero = sc.nextInt();
                        System.out.println("El factorial de "+ numero+" es: "+ Factorial(numero));
    }
}
