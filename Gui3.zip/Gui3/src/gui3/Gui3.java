/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author salas
 */
public class Gui3 extends JFrame{
JButton TotalizarValores;
JTextField a, b, c;
ButtonGroup operacion;
JRadioButton suma, resta, multiplicacion, division;

    public Gui3(){
        setLayout(new GridLayout(5,2));
        a = new JTextField(5);
            add(a);
        b = new JTextField(5);
            add(b);
        add( new JLabel("Total"));
        c = new JTextField(5);
            add(c);
        c.setEditable(false);
        
        operacion = new ButtonGroup();
        suma = new JRadioButton("Suma");
        resta = new JRadioButton("Resta");
        multiplicacion = new JRadioButton("Multiplicación");
        division = new JRadioButton("División");
            add(suma);
                operacion.add(suma);
            add(resta);
                operacion.add(resta);
            add(multiplicacion);
                operacion.add(multiplicacion);
            add(division);
                operacion.add(division);
            TotalizarValores = new JButton("Totalizar");
                add(TotalizarValores);
            TotalizarValores.addActionListener(new OyenteBoton());
                setSize(400,150);
                setVisible(true);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public static void main(String args[]){
 Gui3 Ventana = new Gui3();}

class OyenteBoton implements ActionListener{
public void actionPerformed(ActionEvent e){
    double total=0;
        if(suma.isSelected()){
            total=Double.parseDouble(a.getText())+Double.parseDouble(b.getText());}
        if(resta.isSelected()){
            total=Double.parseDouble(a.getText())-Double.parseDouble(b.getText());}
        if(multiplicacion.isSelected()){
            total=Double.parseDouble(a.getText())*Double.parseDouble(b.getText());}
        if(division.isSelected()){
            total=Double.parseDouble(a.getText())/Double.parseDouble(b.getText());}
    String t = String.valueOf(total);
    c.setText(t);
}
}
}
  
