/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author salas
 */
public class Gui1 extends JFrame {
JButton BotonCalcular;
JTextField campoNombre,campoSalario, campoBonoPorcentaje, Salario;   
public Gui1(){
setLayout(new FlowLayout());
    add(new JLabel("Nombre del empleado: "));
campoNombre = new JTextField(5);
    add(campoNombre);
    add(new JLabel("Salario del empleado: "));
campoSalario = new JTextField(5);
    add(campoSalario);
    add(new JLabel("bono porcentual: "));
campoBonoPorcentaje = new JTextField(5);
    add(campoBonoPorcentaje);

BotonCalcular=new JButton("Calcular Salario");
    add(BotonCalcular);
        BotonCalcular.addActionListener(new OyenteBoton());
            add(new JLabel("Salario total"));
Salario = new JTextField(6);
add(Salario);
   
setSize(1000, 100);
setVisible(true);
}

public static void main(String args[]){
 Gui1 Ventana = new Gui1();
}

class OyenteBoton implements ActionListener{
public void actionPerformed(ActionEvent e){
String Salarioo = campoSalario.getText();
double Salariooo=Double.parseDouble(Salarioo);
String Persent = campoBonoPorcentaje.getText();
double Persentt=Double.parseDouble(Persent);
double Sal=Salariooo+Salariooo*(Persentt/100);
String Sall= String.valueOf(Sal);
Salario.setText(Sall);
}}}