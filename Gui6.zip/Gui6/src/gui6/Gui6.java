/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui6;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author salas
 */
public class Gui6 extends JFrame {
    JMenuBar Barra;
    JMenu Archivo, Edicion;
    JMenuItem Opcion1, Opcion2, Opcion3, SM1, SM2;
    
    public Gui6(){
        FlowLayout F = new FlowLayout();
            F.setAlignment(0);
                setLayout(F);
        Barra = new JMenuBar();
            add(Barra);
        Archivo = new JMenu("Archivo");
            Barra.add(Archivo);
        Edicion = new JMenu("Edición");
            Barra.add(Edicion);
        
        Opcion1 = new JMenuItem("Opción 1:");
            Archivo.add(Opcion1);
                Opcion1.addActionListener(new menu1());
                
        Archivo.add(new JSeparator());
        
        Opcion3 = new JMenuItem("Opción 3:");
            Archivo.add(Opcion3);
                SM1 = new JMenuItem("SubMenú 1");
                    Opcion3.add(SM1);
                SM2 = new JMenuItem("SubMenú 2");
                    Opcion3.add(SM2);
        setSize(1350, 700);
        setVisible(true);
        setTitle("Sistema IUE");
        setDefaultCloseOperation(EXIT_ON_CLOSE);    
    }  
    
public static void main(String args[]){
    Gui6 ventana = new Gui6();}

class menu1 implements ActionListener{
public void actionPerformed(ActionEvent e){
    Gui4 ventana2 = new Gui4();
}    
}
}
