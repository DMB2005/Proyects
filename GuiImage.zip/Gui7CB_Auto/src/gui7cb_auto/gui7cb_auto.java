/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui7cb_auto;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author salas
 */
public class gui7cb_auto extends JFrame {
    JComboBox Categorias;
    JButton agregarCategoria;
    JTextField categoria;
        
        ControladorCategoria c = new ControladorCategoria(10);
        
        public gui7cb_auto(){
            setLayout(new FlowLayout());
            
            add(new JLabel("Categoría: "));
                categoria = new JTextField(10);
                    add(categoria);
                
            agregarCategoria = new JButton("Agregar categoría");
                add(agregarCategoria);
                    agregarCategoria.addActionListener(new accionBoton());
                    
            add(new JLabel("Categoría: "));
                Categorias = new JComboBox();
                    add(Categorias);
                    
            setSize(320, 130);
            setVisible(true);
            setTitle("Registrar categoria");
            setDefaultCloseOperation(EXIT_ON_CLOSE);
        }

        public static void main (String args[]){
            gui7cb_auto ventana = new gui7cb_auto();
        }
        
        class accionBoton implements ActionListener{
            public void actionPerformed(ActionEvent e){
                c.añadirCategoria(categoria.getText());
                Categorias.addItem(categoria.getText());
                categoria.setText(null);
                JOptionPane.showMessageDialog(null, "La categoría se almacenó satisfactoriamente");
            }
        }
}

