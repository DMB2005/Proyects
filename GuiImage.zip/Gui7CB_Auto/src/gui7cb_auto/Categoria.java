/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui7cb_auto;

/**
 *
 * @author salas
 */
public class Categoria {
private String nombre;

    Categoria(String n) {
        nombre=n;
    }

    public void setNombre(String n) {
        this.nombre = n;
    }
    public String getNombre() {
        return nombre;
    }
    
    @Override
    public String toString() {
        return "Gui7CB_Auto{" + "nombre=" + nombre + '}';
    } 
}
