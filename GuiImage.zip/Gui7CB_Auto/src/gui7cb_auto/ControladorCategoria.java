/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui7cb_auto;

/**
 *
 * @author salas
 */
public class ControladorCategoria {
    Categoria c[];
    int cont;

    ControladorCategoria(int n){
        c = new Categoria[n];
            cont=0;}
    
    public void añadirCategoria(String nom){
        c[cont] = new Categoria(nom);
            cont++;
    }

    public Categoria[] getCategoria() {
        return c;
    }

    public int getCont() {
        return cont;
    }
    
    
}
