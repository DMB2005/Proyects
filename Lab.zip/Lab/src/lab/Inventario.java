/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

import java.util.Scanner;

/**
 *
 * @author salas
 */
public class Inventario {
static Scanner sc=new Scanner(System.in);
static Lab ps[]=new Lab[3];

    public static void main(String arg[]){
        IngData();
            ps[0]=ps[2];
            Analgesicos A1;
            Antiinfecciosos S1;
        
    for(int i=0;i<ps.length; i++){
        if(ps[i] instanceof Analgesicos){
        A1=(Analgesicos)ps[i];
        System.out.println("la info del analgesico es: "+A1.toString());     
    } 
    if(ps[i] instanceof Antiinfecciosos){
        S1=(Antiinfecciosos)ps[i];
            System.out.println("la info del medicamento antiinfeccioso es: "+S1.toString());
    }
    }
    }
    
    public static void IngData(){
      String c,nom, efs;
      int v, tpub, dmax, elec;
      boolean d;
      
      for(int i=0; i<ps.length; i++){
          System.out.println("ingrese 1 si es analgesico o 2 si es antiinfeccioso");
            tpub=sc.nextInt();
          System.out.println("Codigo: ");
            c=sc.next();
          System.out.println("Nombre: ");
            sc.nextLine();
            nom=sc.nextLine();
           System.out.println("valor: ");
            v=sc.nextInt();
            
        if(tpub==1){
                System.out.println("efectos secundarios: ");
                efs=sc.next();
                
                System.out.println("genera dependencia(1 para si 2 para no): ");
                    elec=sc.nextInt();
                if (elec==1)
                    d=true;
                else 
                    d=false;
                
            ps[i]=new Analgesicos(c, nom, v, efs, d);
        }
        
        if(tpub==2){
            System.out.println("Dosis maxima: ");
                dmax=sc.nextInt();
            
            ps[i]=new Antiinfecciosos(c, nom, v, dmax);
            
        }
      
        if((tpub==1)&&(tpub==2)){
            System.out.println("Ingreso un valor incorrecto; Ingrese 1 si es Antianalgesico o 2 si es Antiinfeccioso");
                i--;
      }
      }
    }

}
