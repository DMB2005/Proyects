/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

/**
 *
 * @author salas
 */
public class Antiinfecciosos extends Lab{
    private int DosisMax;

    public Antiinfecciosos(String codigo, String nombre, int costo, int DosisMax) {
        super(codigo, nombre, costo);
        this.DosisMax = DosisMax;
        
        
    }

    @Override
    public String toString() {
        return "Antiinfecciosos{" + "DosisMax=" + DosisMax + '}';
    }
  
}
