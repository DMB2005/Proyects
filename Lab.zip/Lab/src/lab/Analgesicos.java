/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

/**
 *
 * @author salas
 */
public class Analgesicos extends Lab {
        private String EfSecundario;
        private boolean Dependencia;

    public Analgesicos(String codigo, String nombre, int costo, String EfSecundario, boolean Dependencia) {
        super(codigo, nombre, costo);
        this.EfSecundario = EfSecundario;
        this.Dependencia = Dependencia;
    }

    @Override
    public String toString() {
        return "Analgesicos{" + "EfSecundario=" + EfSecundario + ", Dependencia=" + Dependencia + '}';
    }
    
    
}

