/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planeta;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author salas
 */
public class Gui5 extends JFrame {
    JButton Guardar,ListarP;
    JTextField Codigo, Nombre;
    
    Planeta p[] = new Planeta[10];
        int cont = 0;
    
 public Gui5(){        
    setLayout(new FlowLayout());
    
    add(new JLabel("Codigo: "));
        Codigo = new JTextField(18);
            add(Codigo);
    add(new JLabel("Nombre: "));
        Nombre = new JTextField(18);
            add(Nombre);
    
    Guardar=new JButton("Guardar Planeta");
        add(Guardar);
            Guardar.addActionListener(new Boton1());
    ListarP=new JButton("Lista de Planetas");
        add(Guardar);
            Guardar.addActionListener(new Boton2());
            
    setSize(300,150);
    setVisible(true);
    setTitle("Registro de Planetas");
    setDefaultCloseOperation(EXIT_ON_CLOSE);
}
public static void main(String args[]){
 Gui5 Ventana = new Gui5();
}

class Boton1 implements ActionListener{
    public void actionPerformed(ActionEvent e){ 

    p[cont] = new Planeta(Codigo.getText(), Nombre.getText());
        cont++;
    Codigo.setText(null);
    Nombre.setText(null);
    JOptionPane.showMessageDialog(null, "El planeta se almacenó satisfactoriamente.");
    }
}

class Boton2 implements ActionListener{
    public void actionPerformed(ActionEvent e){ 
 
    String Planetas = "Los planetas registrados son: ";
    
    for  (int i=0; i<cont; i++)
        Planetas = Planetas+p[i].toString();
    JOptionPane.showMessageDialog(null, Planetas);
    }
}
}
